import requests
import pandas as pd
import os
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib

# Use TkAgg for IDLE
matplotlib.use("TkAgg")

# Fetch transactions
# Ask user for block range
BlockNumberStart = input("Enter start block number (try 13481773): ")
BlockNumberEnd = input("Enter end block number (try 13481774): ")
APIKey = "B1PEXIHJYXFEMXUGHGG5ENTADBJFMUMGDH"

# Build API URL
url = (
    f"https://api.etherscan.io/v2/api"
    f"?chainid=1&module=account&action=txlistinternal"
    f"&startblock={BlockNumberStart}&endblock={BlockNumberEnd}"
    f"&page=1&offset=10&sort=asc&apikey={APIKey}"
)

# Make request
r = requests.get(url)
data = r.json()

# Check status before converting to DataFrame
if data.get("status") == "1" and "result" in data and len(data["result"]) > 0:
    df = pd.DataFrame(data["result"])
    df["bot activity"] = "N/A"  # placeholder
    print(df)
else:
    print("No transactions found or error in response:")
    print(data)
    df = pd.DataFrame()  # empty dataframe to avoid errors later

# Save/append to CSV
DATA_FILE = "all_transactions.csv"

if not df.empty:
    if os.path.exists(DATA_FILE):
        existing_df = pd.read_csv(DATA_FILE)
        combined_df = pd.concat([existing_df, df], ignore_index=True)
    else:
        combined_df = df

    combined_df.to_csv(DATA_FILE, index=False)

# Prepare data for visualization 
if not df.empty:
    df["timeStamp"] = pd.to_numeric(df["timeStamp"], errors='coerce')
    df["timeStamp"] = pd.to_datetime(df["timeStamp"], unit='s')
    df["value"] = df["value"].astype(float) / 1e18
    df["MEV_activity"] = df["bot activity"].apply(lambda x: 1 if x != "N/A" else 0)

    sns.set(style="whitegrid")

    #Visualization 1: MEV vs Regular Transactions per Block 
    plt.figure(figsize=(12,6))
    sns.countplot(data=df, x="blockNumber", hue="MEV_activity")
    plt.title("MEV vs Regular Transactions per Block")
    plt.xlabel("Block Number")
    plt.ylabel("Number of Transactions")
    plt.show()

    # Visualization 2: Transaction Value Distribution 
    plt.figure(figsize=(12,6))
    sns.histplot(data=df, x="value", bins=20, hue="MEV_activity", kde=True)
    plt.title("Transaction Value Distribution: MEV vs Regular")
    plt.xlabel("ETH Value")
    plt.ylabel("Frequency")
    plt.show()

    # Visualization 3: MEV Activity Timeline 
    plt.figure(figsize=(14,6))
    sns.lineplot(data=df, x="timeStamp", y="MEV_activity", marker="o")
    plt.title("MEV Activity Over Time")
    plt.xlabel("Timestamp")
    plt.ylabel("MEV Transactions (1=MEV, 0=Normal)")
    plt.show()

    # Visualization 4: Boxplot of Transaction Values by MEV 
    plt.figure(figsize=(12,6))
    sns.boxplot(data=df, x="MEV_activity", y="value")
    plt.title("Transaction Value Comparison: MEV vs Regular")
    plt.xlabel("MEV Activity (0=Normal, 1=MEV)")
    plt.ylabel("ETH Value")
    plt.show()
else:
    print("No data available for visualization.")