import requests
import pandas as pd

# Ask user for block range
BlockNumberStart = input("Enter start block number (try 13481773): ")
BlockNumberEnd = input("Enter end block number (try 13481773): ")
APIKey = "B1PEXIHJYXFEMXUGHGG5ENTADBJFMUMGDH"

# Build API URL
url = (
    f"https://api.etherscan.io/v2/api"
    f"?chainid=1&module=account&action=txlistinternal"
    f"&startblock={BlockNumberStart}&endblock={BlockNumberEnd}"
    f"&page=1&offset=10&sort=asc&apikey={APIKey}"
)

# Make request
r = requests.get(url)
data = r.json()

# Step 3: Check status before converting to DataFrame
if data.get("status") == "1" and "result" in data:
    df = pd.DataFrame(data["result"])
    
    # Add new column "bot activity" filled with N/A
    df["bot activity"] = "N/A"
    
    print(df)
else:
    print("No transactions found or error in response:")
    print(data)